<?php

define('Consumer_Key','TwWAgjpKEUd6dTHtfqoLuYmqB');
define('Consumer_Secret','1Pnyedb9AfwKGO6RTO8qrLz7McCF57eaDrYatWlfOpxpHHlEs1');
?>