<?php
session_start();
include("config.php");
require "autoload.php";
use Abraham\TwitterOAuth\TwitterOAuth;
if(isset($_SESSION['t1']))
{
	// echo "ok";
}
else{
	$connection = new TwitterOAuth(Consumer_Key, Consumer_Secret, $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
	 
	$access_token = $connection->oauth('oauth/access_token', array('oauth_verifier' => $_REQUEST['oauth_verifier'], 'oauth_token'=> $_GET['oauth_token']));
	
	$_SESSION['t1']=$access_token['oauth_token'];
	$_SESSION['t2']=$access_token['oauth_token_secret'];
}
if(isset($_SESSION['tweeting'])) header("location:trend_tweet.php");
else 	header("location:index.php");
	
// print_r($user_info);
// echo $user_info->id."<br>";
// echo $user_info->name;

/*$statues = $connection->post("statuses/update", ["status" => "Evaraina unara online lo???"]);
if($connection->getLastHttpCode() == 200){
	echo"Succeeded";
}
else{
	echo "Nope";
}
*/

?>